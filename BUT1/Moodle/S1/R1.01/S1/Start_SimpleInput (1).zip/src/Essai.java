/**
* Essai de programme Java pour la ressource R1.01
* @author M.Adam
**/
class Essai{
	void principal(){
		System.out.println("Hello World !");
    }
}
